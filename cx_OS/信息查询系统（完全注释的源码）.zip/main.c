#include "function.c"

int main(){
    list L;         // 建立一个学生表
    init(&L);       // 初始化 这个 表
    welcome(&L);    // 进入 【欢迎界面】
    return 0;
}