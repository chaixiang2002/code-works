#include "function.c"

int main(){
    list L;
    init(&L);
    welcome(&L);
    return 0;
}